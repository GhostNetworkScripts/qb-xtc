fx_version 'cerulean'
game 'gta5'

description 'Gh-xtc'
version '1.0.0'

shared_script '@qb-core/shared.lua'
-- shared_script '@qb-core/shared/items.lua'
server_script 'server/main.lua'
client_script 'client/main.lua'
