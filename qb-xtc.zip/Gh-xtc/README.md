# INFORMATION
This is 2 steps drugs prosses only simple but clean and fun for youre server

# PREVIEW


# DEPENDENCIES
- QBCore Framework
- qb-skillbar
- qb-inventory or other 
- qb-core


# CHANGE
You can change the locations if you like for example you using mlo's or if you just want to change it you can do this in the client and change vector3 stuff

# ADD THIS IN TO QBCORE-->Shared-->items.lua
['xtci'] 			 	 	 	 = {['name'] = 'xtci', 			  			['label'] = 'Xtc ingredients', 					['weight'] = 100, 		['type'] = 'item', 		['image'] = 'Xtcingredients.png', 				['unique'] = false, 		['useable'] = false, 	['shouldClose'] = false,   ['combinable'] = nil,   ['description'] = 'Ummmm Lets go crazyy!!!'},

# ADD THE PNG PICTURE INTO INVENTORY HTML IMGES

# SCRIPT BY GHOSTNETWORK

# Add this in QB-Drugs --> Config.lua Line 144
    ["xtcbaggy"] = {
        min = 15,
        max = 55,
    },
